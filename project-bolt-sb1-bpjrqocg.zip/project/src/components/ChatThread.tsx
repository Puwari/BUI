import { useEffect, useRef } from "react";
import { Sparkles, RefreshCw, Copy, ThumbsUp, ThumbsDown } from "lucide-react";

export type Role = "user" | "assistant";
export interface Message {
  id: string;
  role: Role;
  text: string;
  pending?: boolean;
  time: string;
}

const mockReply =
  "ทำความเข้าใจง่ายๆ ก่อนนะ\n\n**B-tree** และ **B+ tree** ต่างกันหลักที่การเก็บข้อมูล:\n\n**B-tree**: ข้อมูลเก็บในทุก node ทั้ง internal และ leaf\n**B+ tree**: ข้อมูลเก็บเฉพาะที่ leaf nodes เท่านั้น ส่วน internal nodes เก็บแค่ key สำหรับ index\n\nผลกระทบต่อการใช้งาน:\n- range query: B+ tree เร็วกว่า เพราะ leaf เชื่อมกันเป็น linked list\n- search ค่าเดียว: B-tree อาจหาเจอเร็วกว่า เพราะเจอแล้วจบเลย ไม่ต้องไล่ต่อถึง leaf\n- space: B+ tree internal node เก็บ key ได้เยอะกว่า → tree ต่ำกว่า → I/O น้อยกว่า\n\nเหตุผลที่ database ส่วนใหญ่เลือก B+ tree คือ range query และ sequential access มีประสิทธิภาพดีกว่า ซึ่งตรงกับ access pattern ของ database ที่ใช้ WHERE range และ ORDER BY บ่อย";

export function generateReply(): string {
  return mockReply;
}

export default function ChatThread({ messages }: { messages: Message[] }) {
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages]);

  return (
    <div style={{ flex: 1, overflowY: "auto", overflowX: "hidden" }}>
      <div
        style={{
          width: "100%",
          maxWidth: "var(--measure)",
          margin: "0 auto",
          padding: "32px 20px 24px",
          display: "flex",
          flexDirection: "column",
          gap: 24,
        }}
      >
        {messages.map(m => (m.role === "user" ? <UserBubble key={m.id} m={m} /> : <AssistantBubble key={m.id} m={m} />))}
        <div ref={endRef} style={{ height: 1 }} />
      </div>
    </div>
  );
}

function UserBubble({ m }: { m: Message }) {
  return (
    <div style={{ display: "flex", gap: 12, justifyContent: "flex-end" }}>
      <div
        style={{
          maxWidth: "78%",
          padding: "10px 14px",
          background: "var(--brand)",
          color: "#fff",
          borderRadius: "var(--r-lg) var(--r-lg) var(--r-sm) var(--r-lg)",
          fontSize: "0.9rem",
          lineHeight: 1.6,
          boxShadow: "var(--shadow-sm)",
          whiteSpace: "pre-wrap",
          wordBreak: "break-word",
        }}
      >
        {m.text}
      </div>
      <Avatar role="user" />
    </div>
  );
}

function AssistantBubble({ m }: { m: Message }) {
  return (
    <div style={{ display: "flex", gap: 12 }}>
      <Avatar role="assistant" />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div
          style={{
            fontSize: "0.75rem",
            color: "var(--ink-3)",
            marginBottom: 4,
            display: "flex",
            alignItems: "center",
            gap: 6,
          }}
        >
          <span style={{ fontWeight: 600, color: "var(--brand-ink)" }}>BU Mind</span>
          <span>·</span>
          <span>{m.time}</span>
        </div>
        <div
          style={{
            padding: "16px 16px",
            background: "var(--surface)",
            border: "1px solid var(--line)",
            borderRadius: "var(--r-sm) var(--r-lg) var(--r-lg) var(--r-lg)",
            fontSize: "0.9rem",
            lineHeight: 1.65,
            color: "var(--ink)",
            boxShadow: "var(--shadow-sm)",
          }}
        >
          {m.pending ? <TypingDots /> : <FormattedText text={m.text} />}
        </div>

        {!m.pending && (
          <div style={{ display: "flex", gap: 4, marginTop: 8, marginLeft: 4 }}>
            <ActionBtn icon={<Copy size={14} />} label="คัดลอก" />
            <ActionBtn icon={<RefreshCw size={14} />} label="ตอบใหม่" />
            <ActionBtn icon={<ThumbsUp size={14} />} />
            <ActionBtn icon={<ThumbsDown size={14} />} />
          </div>
        )}
      </div>
    </div>
  );
}

function Avatar({ role }: { role: Role }) {
  if (role === "user") {
    return (
      <div
        style={{
          width: 32,
          height: 32,
          borderRadius: "8px",
          background: "var(--iti-tint)",
          color: "var(--iti-500)",
          display: "grid",
          placeItems: "center",
          fontWeight: 700,
          fontSize: "0.82rem",
          fontFamily: "var(--font-head)",
          flexShrink: 0,
        }}
      >
        ธ
      </div>
    );
  }
  return (
    <div
      style={{
        width: 32,
        height: 32,
        borderRadius: "8px",
        background: "linear-gradient(135deg, var(--purple-600), var(--purple-400))",
        color: "#fff",
        display: "grid",
        placeItems: "center",
        flexShrink: 0,
        boxShadow: "0 2px 8px rgba(63, 25, 75, 0.25)",
      }}
    >
      <Sparkles size={17} />
    </div>
  );
}

function ActionBtn({ icon, label }: { icon: React.ReactNode; label?: string }) {
  return (
    <button
      style={{
        display: "flex",
        alignItems: "center",
        gap: 5,
        padding: "5px 8px",
        borderRadius: "var(--r-sm)",
        border: "none",
        background: "transparent",
        color: "var(--ink-3)",
        cursor: "pointer",
        fontSize: "0.75rem",
        transition: "background var(--dur) var(--ease), color var(--dur) var(--ease)",
      }}
      onMouseEnter={e => {
        (e.currentTarget as HTMLButtonElement).style.background = "var(--sunken)";
        (e.currentTarget as HTMLButtonElement).style.color = "var(--brand-ink)";
      }}
      onMouseLeave={e => {
        (e.currentTarget as HTMLButtonElement).style.background = "transparent";
        (e.currentTarget as HTMLButtonElement).style.color = "var(--ink-3)";
      }}
    >
      {icon}
      {label && <span>{label}</span>}
    </button>
  );
}

function TypingDots() {
  return (
    <div style={{ display: "flex", gap: 5, alignItems: "center", height: 22 }}>
      {[0, 1, 2].map(i => (
        <span
          key={i}
          style={{
            width: 7,
            height: 7,
            borderRadius: "50%",
            background: "var(--purple-700)",
            opacity: 0.4,
            animation: `caret 1.2s ${i * 0.18}s ease infinite`,
          }}
        />
      ))}
    </div>
  );
}

// Lightweight markdown-ish renderer: **bold**, line breaks, bullet lists
function FormattedText({ text }: { text: string }) {
  const blocks: React.ReactNode[] = [];
  const lines = text.split("\n");
  let listBuffer: string[] = [];

  const flushList = (key: string) => {
    if (listBuffer.length === 0) return;
    blocks.push(
      <ul key={key} style={{ margin: "0 0 12px", paddingLeft: "1.1rem", listStyle: "none" }}>
        {listBuffer.map((li, i) => (
          <li key={i} style={{ position: "relative", paddingLeft: "10px", marginBottom: 4 }}>
            <span
              style={{
                position: "absolute",
                left: 0,
                top: 12,
                width: 4,
                height: 4,
                borderRadius: "50%",
                background: "var(--purple-700)",
              }}
            />
            <Inline text={li} />
          </li>
        ))}
      </ul>
    );
    listBuffer = [];
  };

  lines.forEach((line, i) => {
    const trimmed = line.trim();
    if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
      listBuffer.push(trimmed.slice(2));
    } else {
      flushList(`ul-${i}`);
      if (trimmed === "") {
        blocks.push(<div key={`sp-${i}`} style={{ height: 8 }} />);
      } else {
        blocks.push(
          <p key={`p-${i}`}>
            <Inline text={line} />
          </p>
        );
      }
    }
  });
  flushList("ul-end");

  return <>{blocks}</>;
}

function Inline({ text }: { text: string }) {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return (
    <>
      {parts.map((p, i) => {
        if (p.startsWith("**") && p.endsWith("**")) {
          return (
            <strong key={i} style={{ color: "var(--brand-ink)", fontWeight: 700 }}>
              {p.slice(2, -2)}
            </strong>
          );
        }
        return <span key={i}>{p}</span>;
      })}
    </>
  );
}
