import { ChevronDown, Share2, MoreHorizontal, Info } from "lucide-react";

export default function TopBar() {
  return (
    <header
      style={{
        height: 56,
        flexShrink: 0,
        background: "var(--surface)",
        borderBottom: "1px solid var(--line)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "0 20px 0 24px",
        gap: 12,
      }}
    >
      {/* Model selector */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          padding: "6px 12px",
          borderRadius: "var(--r-pill)",
          background: "var(--paper)",
          border: "1px solid var(--line)",
          cursor: "pointer",
          fontSize: "0.9rem",
          fontWeight: 600,
          color: "var(--brand-ink)",
          transition: "background var(--dur) var(--ease), border-color var(--dur) var(--ease)",
        }}
        onMouseEnter={e => {
          (e.currentTarget as HTMLDivElement).style.background = "var(--brand-tint)";
          (e.currentTarget as HTMLDivElement).style.borderColor = "var(--brand-tint-2)";
        }}
        onMouseLeave={e => {
          (e.currentTarget as HTMLDivElement).style.background = "var(--paper)";
          (e.currentTarget as HTMLDivElement).style.borderColor = "var(--line)";
        }}
      >
        <span
          style={{
            width: 7,
            height: 7,
            borderRadius: "50%",
            background: "var(--ok)",
            boxShadow: "0 0 0 3px var(--ok-tint)",
            flexShrink: 0,
          }}
        />
        <span>BU Mind</span>
        <span style={{ color: "var(--ink-3)", fontWeight: 400 }}>· v4</span>
        <ChevronDown size={15} color="var(--ink-3)" />
      </div>

      {/* Right actions */}
      <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
        <button style={iconBtn} onMouseEnter={hoverIcon(true)} onMouseLeave={hoverIcon(false)}>
          <Share2 size={17} />
        </button>
        <button style={iconBtn} onMouseEnter={hoverIcon(true)} onMouseLeave={hoverIcon(false)}>
          <Info size={17} />
        </button>
        <button style={iconBtn} onMouseEnter={hoverIcon(true)} onMouseLeave={hoverIcon(false)}>
          <MoreHorizontal size={17} />
        </button>
      </div>
    </header>
  );
}

const iconBtn: React.CSSProperties = {
  display: "grid",
  placeItems: "center",
  width: 34,
  height: 34,
  borderRadius: "var(--r-md)",
  border: "none",
  background: "transparent",
  color: "var(--ink-2)",
  cursor: "pointer",
  transition: "background var(--dur) var(--ease), color var(--dur) var(--ease)",
};

function hoverIcon(enter: boolean) {
  return (e: React.MouseEvent) => {
    const el = e.currentTarget as HTMLButtonElement;
    el.style.background = enter ? "var(--sunken)" : "transparent";
    el.style.color = enter ? "var(--brand-ink)" : "var(--ink-2)";
  };
}
