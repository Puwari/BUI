import { useRef, useState, useEffect } from "react";
import { ArrowUp, Paperclip, Mic, Sparkles, Image as ImageIcon } from "lucide-react";

interface ComposerProps {
  onSend: (text: string) => void;
  disabled: boolean;
}

const suggestions = ["อธิบายเรื่อง B-tree", "สรุปบทเรียน CS332", "ช่วยแก้โค้ด Python", "วางแผนอ่านหนังสือสอบ"];

export default function Composer({ onSend, disabled }: ComposerProps) {
  const [value, setValue] = useState("");
  const taRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 200) + "px";
  }, [value]);

  const send = () => {
    const t = value.trim();
    if (!t || disabled) return;
    onSend(t);
    setValue("");
  };

  return (
    <div
      style={{
        flexShrink: 0,
        padding: "8px 16px 14px",
        background: "linear-gradient(to bottom, transparent, var(--paper) 30%)",
      }}
    >
      <div style={{ maxWidth: "var(--measure)", margin: "0 auto" }}>
        <div
          style={{
            background: "var(--surface)",
            border: "1px solid var(--line-2)",
            borderRadius: "var(--r-lg)",
            boxShadow: "var(--shadow-sm)",
            padding: "6px 6px 6px 12px",
            display: "flex",
            alignItems: "center",
            gap: 6,
            transition: "border-color var(--dur) var(--ease), box-shadow var(--dur) var(--ease)",
          }}
        >
          {/* attach */}
          <button style={iconBtn} title="แนบไฟล์" onMouseEnter={hoverIcon(true)} onMouseLeave={hoverIcon(false)}>
            <Paperclip size={16} />
          </button>

          {/* textarea */}
          <textarea
            ref={taRef}
            value={value}
            onChange={e => setValue(e.target.value)}
            onKeyDown={e => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send();
              }
            }}
            rows={1}
            placeholder="ถามอะไรก็ได้ เกี่ยวกับการเรียน..."
            style={{
              flex: 1,
              border: "none",
              outline: "none",
              resize: "none",
              background: "transparent",
              fontFamily: "var(--font-sans)",
              fontSize: "0.88rem",
              lineHeight: 1.5,
              color: "var(--ink)",
              padding: "6px 2px",
              maxHeight: 160,
              overflowY: "auto",
            }}
          />

          {/* secondary actions */}
          <button style={iconBtn} title="รูปภาพ" onMouseEnter={hoverIcon(true)} onMouseLeave={hoverIcon(false)}>
            <ImageIcon size={16} />
          </button>
          <button style={iconBtn} title="เสียง" onMouseEnter={hoverIcon(true)} onMouseLeave={hoverIcon(false)}>
            <Mic size={16} />
          </button>

          {/* send */}
          <button
            onClick={send}
            disabled={disabled || !value.trim()}
            style={{
              width: 32,
              height: 32,
              borderRadius: "var(--r-sm)",
              border: "none",
              background: value.trim() && !disabled ? "var(--brand)" : "var(--sunken)",
              color: value.trim() && !disabled ? "#fff" : "var(--ink-3)",
              cursor: value.trim() && !disabled ? "pointer" : "not-allowed",
              display: "grid",
              placeItems: "center",
              flexShrink: 0,
              transition: "background var(--dur) var(--ease), transform var(--dur) var(--ease)",
            }}
            onMouseEnter={e => {
              if (value.trim() && !disabled) (e.currentTarget as HTMLButtonElement).style.transform = "scale(1.05)";
            }}
            onMouseLeave={e => {
              (e.currentTarget as HTMLButtonElement).style.transform = "scale(1)";
            }}
          >
            <ArrowUp size={16} />
          </button>
        </div>

        {/* suggestions */}
        <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap", alignItems: "center" }}>
          <span
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 5,
              fontSize: "0.72rem",
              color: "var(--ink-3)",
              padding: "3px 9px",
              background: "var(--surface)",
              border: "1px solid var(--line)",
              borderRadius: "var(--r-pill)",
            }}
          >
            <Sparkles size={11} style={{ color: "var(--purple-700)" }} />
            ลองถาม
          </span>
          {suggestions.map(s => (
            <button
              key={s}
              onClick={() => setValue(s)}
              style={{
                fontSize: "0.74rem",
                color: "var(--ink-2)",
                padding: "3px 10px",
                background: "var(--surface)",
                border: "1px solid var(--line)",
                borderRadius: "var(--r-pill)",
                cursor: "pointer",
                transition: "background var(--dur) var(--ease), color var(--dur) var(--ease), border-color var(--dur) var(--ease)",
              }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLButtonElement).style.background = "var(--brand-tint)";
                (e.currentTarget as HTMLButtonElement).style.color = "var(--brand-ink)";
                (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--brand-tint-2)";
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLButtonElement).style.background = "var(--surface)";
                (e.currentTarget as HTMLButtonElement).style.color = "var(--ink-2)";
                (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--line)";
              }}
            >
              {s}
            </button>
          ))}
        </div>

        <p style={{ textAlign: "center", fontSize: "0.68rem", color: "var(--ink-3)", margin: "8px 0 0" }}>
          BU Mind อาจผิดพลาดได้ โปรดตรวจสอบข้อมูลสำคัญ
        </p>
      </div>
    </div>
  );
}

const iconBtn: React.CSSProperties = {
  display: "grid",
  placeItems: "center",
  width: 30,
  height: 30,
  borderRadius: "var(--r-sm)",
  border: "none",
  background: "transparent",
  color: "var(--ink-3)",
  cursor: "pointer",
  flexShrink: 0,
  transition: "background var(--dur) var(--ease), color var(--dur) var(--ease)",
};

function hoverIcon(enter: boolean) {
  return (e: React.MouseEvent) => {
    const el = e.currentTarget as HTMLButtonElement;
    el.style.background = enter ? "var(--sunken)" : "transparent";
    el.style.color = enter ? "var(--brand-ink)" : "var(--ink-3)";
  };
}
