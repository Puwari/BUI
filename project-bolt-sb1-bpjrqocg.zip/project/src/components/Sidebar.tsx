import { MessageSquare, History, Zap, Key, Plus, ChevronRight } from "lucide-react";

interface SidebarProps {
  credits: number;
  activeChat: string;
  onNewChat: () => void;
}

const recent = [
  { id: "1", title: "การบ้าน DS ข้อ 3" },
  { id: "2", title: "B-tree ต่างจาก B+ tree" },
  { id: "3", title: "ปฏิทินสอบปลายภาค" },
  { id: "4", title: "ทบทวน CS332 เข้ารหัส" },
  { id: "5", title: "Sorting algorithm O(n log n)" },
];

export default function Sidebar({ credits, activeChat, onNewChat }: SidebarProps) {
  return (
    <aside
      style={{
        background: "var(--surface)",
        borderRight: "1px solid var(--line)",
        display: "flex",
        flexDirection: "column",
        gap: "2px",
        padding: "16px",
        overflowY: "auto",
        overflowX: "hidden",
        width: "260px",
        flexShrink: 0,
      }}
    >
      {/* Brand */}
      <div style={{ display: "flex", alignItems: "center", gap: "10px", padding: "8px 8px 20px" }}>
        <img
          src="/assets/751516550_1647201693048367_6255511767698128_n.png"
          alt="BU Intelligent Passport"
          style={{ width: 36, height: 36, borderRadius: "8px", objectFit: "cover", flexShrink: 0 }}
        />
        <div
          style={{
            fontFamily: "var(--font-head)",
            fontWeight: 700,
            fontSize: "0.95rem",
            color: "var(--brand-ink)",
            lineHeight: 1.2,
          }}
        >
          BU Intelligent
          <br />
          Passport
        </div>
      </div>

      {/* New chat */}
      <button
        onClick={onNewChat}
        style={{
          display: "flex",
          alignItems: "center",
          gap: "8px",
          width: "100%",
          padding: "10px 12px",
          background: "var(--brand-tint)",
          border: "1px solid var(--brand-tint-2)",
          borderRadius: "var(--r-pill)",
          color: "var(--brand-ink)",
          fontFamily: "var(--font-head)",
          fontWeight: 700,
          fontSize: "0.9rem",
          cursor: "pointer",
          marginBottom: "8px",
          transition: "background var(--dur) var(--ease), box-shadow var(--dur) var(--ease)",
        }}
        onMouseEnter={e => {
          (e.currentTarget as HTMLButtonElement).style.background = "var(--brand-tint-2)";
          (e.currentTarget as HTMLButtonElement).style.boxShadow = "var(--shadow-sm)";
        }}
        onMouseLeave={e => {
          (e.currentTarget as HTMLButtonElement).style.background = "var(--brand-tint)";
          (e.currentTarget as HTMLButtonElement).style.boxShadow = "none";
        }}
      >
        <Plus size={16} />
        บทสนทนาใหม่
      </button>

      {/* Nav items */}
      <NavItem icon={<MessageSquare size={17} />} label="แชท" active />
      <NavItem icon={<History size={17} />} label="ประวัติ" badge="24" />
      <NavItem
        icon={
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.4} strokeLinejoin="round" style={{ width: 17, height: 17 }}>
            <path d="M12 3 19 8 12 21 5 8 Z" />
          </svg>
        }
        label="เครดิตของฉัน"
        badge={credits.toLocaleString()}
      />
      <NavItem icon={<Key size={17} />} label="API key" />

      {/* Recent */}
      <div
        style={{
          fontSize: "0.7rem",
          fontWeight: 700,
          letterSpacing: "0.1em",
          textTransform: "uppercase",
          color: "var(--ink-3)",
          padding: "16px 8px 6px",
        }}
      >
        ล่าสุด
      </div>

      {recent.map(item => (
        <RecentItem key={item.id} title={item.title} active={item.id === activeChat} />
      ))}

      {/* Profile */}
      <div
        style={{
          marginTop: "auto",
          display: "flex",
          alignItems: "center",
          gap: "10px",
          padding: "12px 8px",
          borderTop: "1px solid var(--line)",
        }}
      >
        <div
          style={{
            width: 34,
            height: 34,
            borderRadius: "8px",
            background: "var(--iti-tint)",
            color: "var(--iti-500)",
            display: "grid",
            placeItems: "center",
            fontWeight: 700,
            fontSize: "0.82rem",
            fontFamily: "var(--font-head)",
            flexShrink: 0,
          }}
        >
          ธ
        </div>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div
            style={{
              fontSize: "0.85rem",
              fontWeight: 600,
              color: "var(--ink)",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
            }}
          >
            ธนัชชา ส.
          </div>
          <div style={{ fontSize: "0.72rem", color: "var(--ink-3)" }}>ITI · DSCS ปี 4</div>
        </div>
        <ChevronRight size={14} color="var(--ink-3)" />
      </div>
    </aside>
  );
}

function NavItem({
  icon,
  label,
  active,
  badge,
}: {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  badge?: string;
}) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: "10px",
        padding: "9px 10px",
        borderRadius: "var(--r-md)",
        color: active ? "var(--brand-ink)" : "var(--ink-2)",
        fontWeight: active ? 600 : 400,
        fontSize: "0.925rem",
        cursor: "pointer",
        background: active ? "var(--brand-tint)" : "transparent",
        transition: "background var(--dur) var(--ease), color var(--dur) var(--ease)",
      }}
      onMouseEnter={e => {
        if (!active) {
          (e.currentTarget as HTMLDivElement).style.background = "var(--sunken)";
          (e.currentTarget as HTMLDivElement).style.color = "var(--ink)";
        }
      }}
      onMouseLeave={e => {
        if (!active) {
          (e.currentTarget as HTMLDivElement).style.background = "transparent";
          (e.currentTarget as HTMLDivElement).style.color = "var(--ink-2)";
        }
      }}
    >
      <span style={{ opacity: 0.85, flexShrink: 0 }}>{icon}</span>
      <span style={{ flex: 1 }}>{label}</span>
      {badge && (
        <span
          style={{
            fontSize: "0.75rem",
            color: "var(--ink-3)",
            fontFamily: "var(--font-mono)",
            background: "var(--sunken)",
            padding: "1px 6px",
            borderRadius: "var(--r-pill)",
          }}
        >
          {badge}
        </span>
      )}
    </div>
  );
}

function RecentItem({ title, active }: { title: string; active?: boolean }) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        padding: "7px 10px",
        borderRadius: "var(--r-md)",
        color: active ? "var(--brand-ink)" : "var(--ink-2)",
        fontWeight: active ? 600 : 400,
        fontSize: "0.875rem",
        cursor: "pointer",
        background: active ? "var(--brand-tint)" : "transparent",
        whiteSpace: "nowrap",
        overflow: "hidden",
        textOverflow: "ellipsis",
        transition: "background var(--dur) var(--ease), color var(--dur) var(--ease)",
      }}
      onMouseEnter={e => {
        if (!active) {
          (e.currentTarget as HTMLDivElement).style.background = "var(--sunken)";
          (e.currentTarget as HTMLDivElement).style.color = "var(--ink)";
        }
      }}
      onMouseLeave={e => {
        if (!active) {
          (e.currentTarget as HTMLDivElement).style.background = "transparent";
          (e.currentTarget as HTMLDivElement).style.color = "var(--ink-2)";
        }
      }}
    >
      {title}
    </div>
  );
}
