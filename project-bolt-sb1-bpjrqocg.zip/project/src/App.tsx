import { useState, useCallback } from "react";
import Sidebar from "@/components/Sidebar";
import TopBar from "@/components/TopBar";
import ChatThread, { type Message, generateReply } from "@/components/ChatThread";
import Composer from "@/components/Composer";

const initialMessages: Message[] = [
  {
    id: "m1",
    role: "user",
    text: "B-tree กับ B+ tree ต่างกันยังไง แล้วทำไม database ส่วนใหญ่ถึงเลือก B+ tree?",
    time: "14:32",
  },
  {
    id: "m2",
    role: "assistant",
    text: generateReply(),
    time: "14:32",
  },
];

function nowTime() {
  return new Date().toLocaleTimeString("th-TH", { hour: "2-digit", minute: "2-digit", hour12: false });
}

let idCounter = 100;
function nextId() {
  idCounter += 1;
  return `m${idCounter}`;
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [activeChat, setActiveChat] = useState("1");
  const [busy, setBusy] = useState(false);

  const handleSend = useCallback(
    (text: string) => {
      const userMsg: Message = { id: nextId(), role: "user", text, time: nowTime() };
      const pendingId = nextId();
      const pendingMsg: Message = {
        id: pendingId,
        role: "assistant",
        text: "",
        pending: true,
        time: nowTime(),
      };
      setMessages(prev => [...prev, userMsg, pendingMsg]);
      setBusy(true);

      window.setTimeout(() => {
        setMessages(prev =>
          prev.map(m => (m.id === pendingId ? { ...m, text: generateReply(), pending: false, time: nowTime() } : m))
        );
        setBusy(false);
      }, 1400);
    },
    []
  );

  const handleNewChat = useCallback(() => {
    setMessages([]);
    setActiveChat("");
  }, []);

  return (
    <div style={{ display: "flex", height: "100%", overflow: "hidden", background: "var(--paper)" }}>
      <Sidebar credits={1280} activeChat={activeChat} onNewChat={handleNewChat} />

      <main style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
        <TopBar />

        {messages.length === 0 ? (
          <EmptyState onPick={handleSend} />
        ) : (
          <ChatThread messages={messages} />
        )}

        <Composer onSend={handleSend} disabled={busy} />
      </main>
    </div>
  );
}

function EmptyState({ onPick }: { onPick: (text: string) => void }) {
  const cards = [
    { title: "อธิบายแนวคิด", desc: "อธิบายเรื่อง B-tree กับ B+ tree ให้เข้าใจง่าย", icon: "📚" },
    { title: "สรุปบทเรียน", desc: "สรุปเนื้อหา CS332 บทที่ 4 เรื่อง Hashing", icon: "✏️" },
    { title: "ช่วยแก้โค้ด", desc: "โค้ด Python รันแล้วเจอ IndexError ช่วยดูให้หน่อย", icon: "💻" },
    { title: "วางแผนสอบ", desc: "ช่วยวางแผนอ่านหนังสือ 7 วันก่อนสอบปลายภาค", icon: "🎯" },
  ];

  return (
    <div
      style={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: "32px 24px",
        gap: 24,
        overflowY: "auto",
      }}
    >
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 14, maxWidth: 460, textAlign: "center" }}>
        <div
          style={{
            width: 56,
            height: 56,
            borderRadius: "16px",
            background: "linear-gradient(135deg, var(--purple-600), var(--purple-400))",
            display: "grid",
            placeItems: "center",
            boxShadow: "0 8px 24px rgba(63, 25, 75, 0.25)",
          }}
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round" style={{ width: 28, height: 28 }}>
            <path d="M12 3 19 8 12 21 5 8 Z" />
          </svg>
        </div>
        <h1 style={{ fontSize: "1.6rem" }}>สวัสดี User</h1>
        <p style={{ color: "var(--ink-2)", fontSize: "0.95rem" }}>
          ถามอะไรกับ BU Mind ได้เลย — การบ้าน สรุปบทเรียน แก้โค้ด หรือวางแผนสอบ
        </p>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
          gap: 12,
          width: "100%",
          maxWidth: 560,
        }}
      >
        {cards.map(c => (
          <button
            key={c.title}
            onClick={() => onPick(c.desc)}
            style={{
              textAlign: "left",
              padding: "16px",
              background: "var(--surface)",
              border: "1px solid var(--line)",
              borderRadius: "var(--r-lg)",
              cursor: "pointer",
              transition: "border-color var(--dur) var(--ease), box-shadow var(--dur) var(--ease), transform var(--dur) var(--ease)",
            }}
            onMouseEnter={e => {
              (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--brand-tint-2)";
              (e.currentTarget as HTMLButtonElement).style.boxShadow = "var(--shadow-md)";
              (e.currentTarget as HTMLButtonElement).style.transform = "translateY(-2px)";
            }}
            onMouseLeave={e => {
              (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--line)";
              (e.currentTarget as HTMLButtonElement).style.boxShadow = "none";
              (e.currentTarget as HTMLButtonElement).style.transform = "translateY(0)";
            }}
          >
            <div style={{ fontSize: "1.4rem", marginBottom: 6 }}>{c.icon}</div>
            <div style={{ fontFamily: "var(--font-head)", fontWeight: 700, color: "var(--brand-ink)", fontSize: "0.95rem", marginBottom: 2 }}>
              {c.title}
            </div>
            <div style={{ fontSize: "0.82rem", color: "var(--ink-2)", lineHeight: 1.5 }}>{c.desc}</div>
          </button>
        ))}
      </div>
    </div>
  );
}
